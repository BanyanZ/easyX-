#pragma once
#include<iostream>
#include"manageBook.h"
#include"book.h"
#include<vector>
#include<string>
#include<fstream>
#include<cstdint>
using namespace std;

class ManageBook :public Book
{
private:
	vector<Book> bkarray;

public:
	ManageBook() {}//Ĭ�Ϲ���
	~ManageBook() {}//��������
 
	//������һЩ���ܵ�ʵ��
	//1.����ͼ��
	void addBook(Book newbook) {
		bkarray.push_back(newbook);
	}

	//2.����ͼ�飬ͨ���ع�����ʵ�֣�û�ҵ���return -1
	int findBook(int an) {
		for (int i = 0; i < bkarray.size(); i++) {
			if (bkarray[i].getID() == an) {
				return i;
			}
			else if (bkarray[i].getIsborrowed()) {
				return -2;
			}
		}
		return -1;
	}
	int findBook( string bn ) {//�������������ߣ����ISBN��
		for (int i = 0; i < bkarray.size(); i++) {
			if (bkarray[i].getBookname() == bn || bkarray[i].getAuthor() == bn || bkarray[i].getCategory() == bn || bkarray[i].getISBN() == bn|| bkarray[i].getDate() == bn) {
				return i;
			}
		}
		return -1;
	}

	//3.�޸�ͼ����Ϣ������������ҵ����鼮���ֽ����޸�
	void chgBookID(int idx, int id) {
		bkarray[idx].setID(id);
	}
	void chgBookname(int idx, string um) {
		bkarray[idx].setBookname(um);
	}
	void chgBookAuthor(int idx, string pa) {
		bkarray[idx].setAuthor(pa);
	}
	void chgBookPrice(int idx, int ro) {
		bkarray[idx].setPrice(ro);
	}
	void chgBookCategory(int idx, string rn) {
		bkarray[idx].setCategory(rn);
	}
	void chgBookDate(int idx, string con) {
		bkarray[idx].setDate(con);
	}
	void chgBookIntroduction(int idx, string max) {
		bkarray[idx].setIntroduction(max);
	}
	void chgBookISBN(int idx, string curr) {
		bkarray[idx].setISBN(curr);
	}
	void chgBookIsborrowed(int idx, bool ib) {
		bkarray[idx].setIsborrowed(ib);
	}
	void chgBookPress(int idx, string ie) {
		bkarray[idx].setPress(ie);
	}
	void chgBookTotal(int idx, int to) {
		bkarray[idx].setTotal(to);
	}
	void chgBookLeftnum(int idx, int lef) {
		bkarray[idx].setLeftnum(lef);
	}

	//4.ɾ��ͼ��
	void delBook(int temp) {
		if (!bkarray[temp].getIsborrowed() || bkarray[temp].getLeftnum() == 0) {
			cout << "���鼮״̬�쳣���޷�ɾ��" << endl;
		}
		bkarray[temp].setIsexisting(false);
	}

	//5.���ݻ�����
	void save(string filename)
	{
		ofstream outfile(filename.c_str(), ios::binary);
		if (!outfile.is_open())
		{
			cout << "Error opening file";
			return;
		}
		int bksize = bkarray.size();
		outfile.write((char*)(&bksize), sizeof(bksize));
		for (int i = 0; i < bksize; i++)
			outfile.write((char*)(&bkarray[i]), sizeof(Book));
		outfile.close();
	}

	void load(string filename)
	{
		ifstream infile(filename.c_str(), ios::binary);
		if (!infile.is_open())
		{
			cout << "Error opening file";
			return;
		}
		bkarray.clear();
		int bksize;
		infile.read((char*)(&bksize), sizeof(bksize));
		bkarray.reserve(bksize * 2);
		Book* bookarray = new Book[bksize];
		for (int i = 0; i < bksize; i++)
		{
			infile.read((char*)(&bookarray[i]), sizeof(Book));
			bkarray.push_back(bookarray[i]);
		}
		infile.close();
	}

	//6.����ĳ�������Ϣ
	Book getBook(int idx) {
		return bkarray[idx];
	}

	//7.չʾ����ͼ����Ϣ
	void showAllBooks() {
		cerr << "��ǰͼ������Ϊ��" << bkarray.size() << endl;
		cout << "���е�ͼ��Ϊ" << endl;
		for (int i = 0; i < bkarray.size(); i++)
		{
			if (bkarray[i].getIsexisting())
				bkarray[i].displayBook();
		}
	}

	//8.��������
	vector<Book>& allBooks() { return bkarray; }
};