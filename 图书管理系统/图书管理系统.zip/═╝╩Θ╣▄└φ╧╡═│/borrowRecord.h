#pragma once
#include<iostream>
#include<string>
#include"manageTime.h"
using namespace std;

class BorrowRecord: public ManageTime
{
public:
	int userID_;//�û�ID
	int bookID_;//ͼ��ID
	int borrowID_;//����ID
	string borrowTime_;//����ʱ��
	string shouldReturn_;//Ӧ��ʱ��
	string returnTime_;//ʵ�ʹ黹ʱ��
	int continue_;//ʣ����Ĵ���
	 
public:
	BorrowRecord() {}//Ĭ�Ϲ���
	BorrowRecord(int userID, int bookID, string borrowTime, string shouldReturn, string returnTime, int continueNum, bool isReturned = false, bool isOverdue = false, double fineAmount = 0.0,int borrowID=0)
		:userID_(userID), bookID_(bookID), borrowTime_(borrowTime), shouldReturn_(shouldReturn),borrowID_(borrowID),
		returnTime_(returnTime), continue_(continueNum) {}//�вι���

//����ֵ
	int getUserID()const { return userID_; }
	int getBookID()const { return bookID_; }
	string getBorrowTime()const { return borrowTime_; }
	string getShouldReturnTime()const { return shouldReturn_; }
	string getReturnTime()const { return returnTime_; }
	int getContinue()const { return continue_; }
	int getBorrowID()const { return borrowID_; }

	//����ֵ
	void setUserID(int userID) { userID_ = userID; }
	void setBookID(int bookID) { bookID_ = bookID; }
	void setBorrowTime(const string& borrowTime) { borrowTime_ = borrowTime; }
	void setShouldReturnTime(const string& shouldReturn) { shouldReturn_ = shouldReturn; }
	void setReturnTime(const string& returnTime) { returnTime_ = returnTime; }
	void setContinue(int continueNum) { continue_ = continueNum; }
	void setBprrowID(int borrowID) { borrowID_ = borrowID; }
};